#include "bitwise.h"

#define TODO return 255

bitmask mask(bitpos pos, ...) { TODO; }

bitmask clear(bitmask msk, bitpos pos) { TODO; }

bitmask set(bitmask msk, bitpos pos) { TODO; }

bool is_set(bitmask msk, bitpos pos) { TODO; }

bitmask lsb(wide_bitmask wide_msk) { TODO; }

bitmask msb(wide_bitmask wide_msk) { TODO; }

#include "rtc.h"

#define TODO return -1

int rtc_read_date(rtc_date *date) { TODO; }
